'use strict';
const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const UserSchema = new Schema({
  firstname:String,
  lastname:String,
  password:String, // Number Boolean
  created:Number // Date
});

module.exports = mongoose.model('UserSchema', UserSchema);
