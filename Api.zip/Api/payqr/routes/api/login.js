

module.exports = (app) => {

  app.get('/fuckyouahmad', (req, res, next) => {
    console.log("ahmad bakla")
    res.json({
      "test":"test get"
    })
  })

  app.post('/fuckyouahmad', (req, res, next) => {
    console.log(req.body)


    res.json({
      "test":"test post"
    })
  })

}
