

module.exports = (app) => {

  app.post('/register', (req, res, next) => {
    const response = {
      "status":0,
      "message":null,
      "error":null
    }

    try{

      response['status'] = 1
      response['message'] = 'success'

    }catch(err){
      response['error'] = err.message
    }


    res.json(response)
  })



}
