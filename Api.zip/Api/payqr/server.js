const express = require('express')
const bodyParser  = require('body-parser')
const cors = require('cors')



const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors())

require('./routes')(app);






const port = process.env.PORT || 5656;

// routes go here
app.listen(port, () => {
    console.log(`http://localhost:${port}`)
})
